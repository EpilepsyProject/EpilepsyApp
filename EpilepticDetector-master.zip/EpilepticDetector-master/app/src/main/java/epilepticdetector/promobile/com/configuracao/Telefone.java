package epilepticdetector.promobile.com.configuracao;


public class Telefone {
  public String numero;
  public String tipo;
}